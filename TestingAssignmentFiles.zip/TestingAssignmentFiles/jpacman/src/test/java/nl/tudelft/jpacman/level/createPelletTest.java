package nl.tudelft.jpacman.level;


import nl.tudelft.jpacman.npc.ghost.GhostFactory;
import nl.tudelft.jpacman.points.PointCalculator;
import nl.tudelft.jpacman.sprite.PacManSprites;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.util.*;

public class createPelletTest {



    @Test
    void testCreatePellet()
    {
        /**
         *  Antonio Tessier
         *
         *  Build a Level Factory
         *  Create a pellet
         *  Check if the pellet is null
         *  Have Level Factory assign the pellet
         *  Check if the pellet is no longer null
         */
        PacManSprites sprites = new PacManSprites();    // nl/tudelft/jpacman/npc/ghost/NavigationTest.java
        LevelFactory levelFactory = new LevelFactory(   // Line 42
            sprites,
            new GhostFactory(sprites),
            mock(PointCalculator.class));

        Pellet pellet = null;
        assertThat(pellet).isNull();
        pellet = levelFactory.createPellet();
        assertThat(pellet).isNotNull();

    }
}
