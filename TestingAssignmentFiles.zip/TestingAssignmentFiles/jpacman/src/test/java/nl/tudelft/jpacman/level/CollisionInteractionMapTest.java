package nl.tudelft.jpacman.level;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import nl.tudelft.jpacman.board.Unit;
import nl.tudelft.jpacman.npc.Ghost;
import nl.tudelft.jpacman.points.PointCalculator;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import nl.tudelft.jpacman.level.CollisionMap;

public class CollisionInteractionMapTest {


    private PointCalculator pointCalculator;



    private CollisionInteractionMap defaultCollisions() {                       // nl/tudelft/jpacman/level/DefaultPlayerInteractionMap.java
        CollisionInteractionMap collisionMap = new CollisionInteractionMap();   // Line 46


        collisionMap.onCollision(Player.class, Pellet.class,
            (player, pellet) -> {
                pointCalculator.consumedAPellet(player, pellet);
                pellet.leaveSquare();
            });
        return collisionMap;
    }

    @Test
    void testCollisionInteractionMap()
    {
        /**
         *  Antonio Tessier
         *
         *  Create a collisionMap
         *  Check if it's null by default
         *  Give the map default collisions
         *  Check if the map is no longer null
         */

        CollisionInteractionMap collisionMap = null;
        assertThat(collisionMap).isNull();
        collisionMap = defaultCollisions();
        assertThat(collisionMap).isNotNull();

    }


}
