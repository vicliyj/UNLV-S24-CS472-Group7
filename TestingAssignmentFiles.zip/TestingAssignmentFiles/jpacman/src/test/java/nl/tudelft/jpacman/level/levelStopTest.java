package nl.tudelft.jpacman.level;

import java.util.List;
import com.google.common.collect.Lists;
import nl.tudelft.jpacman.board.Board;
import nl.tudelft.jpacman.board.Square;
import nl.tudelft.jpacman.npc.Ghost;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class levelStopTest {

    private final Ghost ghost = mock(Ghost.class);
    private final Square square1 = mock(Square.class);
    private final Square square2 = mock(Square.class);
    private final Board board = mock(Board.class);
    private List<Square> startPositions;
    private final CollisionMap collisions = mock(CollisionMap.class);

    private Level level;

    @BeforeEach
    void setUp() {
        final long defaultInterval = 100L;
        level = new Level(board, Lists.newArrayList(ghost), Lists.newArrayList(
            square1, square2), collisions);
        when(ghost.getInterval()).thenReturn(defaultInterval);
    }

    @Test
    void testLevelStop()
    {
        /**
         *  Antonio Tessier
         *
         *  Stop the level
         *  Check if it's not in progress
         *  Start the level
         *  Check if it's in progress
         */
        level.stop();
        assertThat(level.isInProgress()).isEqualTo(false);
        level.start();
        assertThat(level.isInProgress()).isEqualTo(true);

    }
}


